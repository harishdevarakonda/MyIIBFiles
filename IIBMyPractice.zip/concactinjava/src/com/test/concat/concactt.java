package com.test.concat;

public class concactt {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(concatMethod("Harish","d"));

	}
	public static String concatMethod(String Fname, String Lname) {

		return "Mr. "+ Fname +" "+Lname;
	}
		
	}


