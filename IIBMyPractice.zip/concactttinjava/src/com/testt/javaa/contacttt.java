package com.testt.javaa;

public class contacttt {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(concatMethod("Harish","Devarakonda"));
}
	public static String concatMethod(String Fname, String Lname) {

		return "Mr. "+ Fname +" "+Lname.toLowerCase();

}
}
